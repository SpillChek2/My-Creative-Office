"""Sample Django application for django-nose testing."""
